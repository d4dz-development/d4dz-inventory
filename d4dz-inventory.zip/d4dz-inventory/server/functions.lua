D4DZCore = exports['d4dz-core']:GetCoreObject()
local activeContainers = {}

-- 1. Calculate the Total Weight of an Inventory
function GetInventoryWeight(inventory)
    local weight = 0
    if not inventory then return weight end
    
    for _, item in pairs(inventory) do
        if item and item.amount then
            local itemConfig = Config.Items[item.name]
            if itemConfig then
                weight = weight + (itemConfig.weight * item.amount)
            end
        end
    end
    return weight
end

-- 2. Safely Save Player Inventory State to Database Core
function SavePlayerInventory(playerId)
    local Player = D4DZCore.Functions.GetPlayer(playerId)
    if not Player then return false end

    local inventoryData = Player.PlayerData.items or {}

    MySQL.Async.execute('UPDATE players SET inventory = ? WHERE citizenid = ?', {
        json.encode(inventoryData),
        Player.PlayerData.citizenid
    }, function(rowsChanged)
        if rowsChanged > 0 then
            print(("[d4dz] Inventory synced and saved securely for Citizen ID: %s"):format(Player.PlayerData.citizenid))
        end
    end)
    return true
end

-- 3. Core Engine Action: Handle Item Movements & Splitting
function HandleItemMovement(sourcePlayerId, data)
    local Player = D4DZCore.Functions.GetPlayer(sourcePlayerId)
    if not Player then return end

    local fromInv = data.fromInventory
    local toInv = data.toInventory
    local fromSlot = tonumber(data.fromSlot)
    local toSlot = tonumber(data.toSlot)
    local moveQty = tonumber(data.quantity)

    -- Basic security verification checks
    if not fromSlot or not toSlot or moveQty <= 0 then return end

    -- Processing Movement Inside Player's Personal Bag
    if fromInv == "player" and toInv == "player" then
        local itemData = Player.PlayerData.items[fromSlot]
        if not itemData or itemData.amount < moveQty then return end

        local targetItem = Player.PlayerData.items[toSlot]

        -- Target slot is empty: relocate item entry safely
        if not targetItem then
            if moveQty == itemData.amount then
                -- FIX: Explicitly rewrite the slot identifier integer inside the object
                itemData.slot = toSlot
                Player.PlayerData.items[toSlot] = itemData
                Player.PlayerData.items[fromSlot] = nil
            else
                -- Partial stack splitting logic split tracking
                Player.PlayerData.items[fromSlot].amount = itemData.amount - moveQty
                Player.PlayerData.items[toSlot] = {
                    name = itemData.name,
                    amount = moveQty,
                    slot = toSlot,
                    image = itemData.image, -- FIX: Carry over image metadata reference 
                    weight = itemData.weight, -- FIX: Carry over weight layout settings
                    info = itemData.info or {}
                }
            end
            
            -- Broadcast immediate visual grid data synchronize refresh down to client UI
            TriggerClientEvent('d4dz_inventory:client:UpdateInventory', sourcePlayerId, Player.PlayerData.items)
        end
    end
end
