local D4DZCore = exports['d4dz-core']:GetCoreObject()

-- 1. Give Item Administrative Command
RegisterCommand('giveitem', function(source, args, rawCommand)
    local src = source

    -- Secure Framework Permission Check (Restricted to admins)
    if src ~= 0 then -- If not executing from server console
        local Player = D4DZCore.Functions.GetPlayer(src)
        if not Player or Player.PlayerData.permission ~= "admin" then
            TriggerClientEvent('d4dz_inventory:client:Notify', src, "You do not have permission to use this command.", "error")
            return
        end
    end

    local targetId = tonumber(args[1])
    local itemName = tostring(args[2]):lower()
    local amount = tonumber(args[3]) or 1

    -- Ensure the designated target player is active in the server cache
    local TargetPlayer = D4DZCore.Functions.GetPlayer(targetId)
    if not TargetPlayer then
        if src == 0 then print("[d4dz] Invalid Player ID selection.") else TriggerClientEvent('d4dz_inventory:client:Notify', src, "Invalid Player ID selection.", "error") end
        return
    end

    -- Verify that the entered item name exists inside config/main.lua
    if not Config.Items[itemName] then
        if src == 0 then print("[d4dz] This item does not exist in the d4dz core registry.") else TriggerClientEvent('d4dz_inventory:client:Notify', src, "This item does not exist in the d4dz core registry.", "error") end
        return
    end

    -- Attempt to inject the item entry using your d4dz-core inventory framework functions
    if TargetPlayer.Functions.AddItem(itemName, amount) then
        -- Refresh visual inventories on screens for the target player
        TriggerClientEvent('d4dz_inventory:client:UpdateInventory', targetId, TargetPlayer.PlayerData.items)
        
        -- Feedback loops
        if src ~= 0 then
            TriggerClientEvent('d4dz_inventory:client:Notify', src, string.format("Gave x%s %s to Player ID %s.", amount, Config.Items[itemName].label, targetId), "success")
        else
            print(string.format("[d4dz] Gave x%s %s to Player ID %s.", amount, Config.Items[itemName].label, targetId))
        end
        TriggerClientEvent('d4dz_inventory:client:Notify', targetId, string.format("Received x%s %s from Staff.", amount, Config.Items[itemName].label), "primary")
    else
        if src == 0 then print("[d4dz] Target player's bag is full.") else TriggerClientEvent('d4dz_inventory:client:Notify', src, "Target player's bag has reached max slots or weight capacity.", "error") end
    end
end, false) -- 'false' means everyone can type it, but our manual if-statement above blocks non-admins safely

-- 2. Clear Inventory Administrative Command
RegisterCommand('clearinventory', function(source, args, rawCommand)
    local src = source

    -- Secure Framework Permission Check
    if src ~= 0 then
        local Player = D4DZCore.Functions.GetPlayer(src)
        if not Player or Player.PlayerData.permission ~= "admin" then
            TriggerClientEvent('d4dz_inventory:client:Notify', src, "You do not have permission to use this command.", "error")
            return
        end
    end

    local targetId = tonumber(args[1])
    local TargetPlayer = D4DZCore.Functions.GetPlayer(targetId)
    if not TargetPlayer then
        if src == 0 then print("[d4dz] Player not found.") else TriggerClientEvent('d4dz_inventory:client:Notify', src, "Player not found.", "error") end
        return
    end

    -- Purge items matrix
    TargetPlayer.PlayerData.items = {}
    
    -- Sync changes immediately to the database via functions.lua
    SavePlayerInventory(targetId)
    TriggerClientEvent('d4dz_inventory:client:UpdateInventory', targetId, {})
    
    if src ~= 0 then
        TriggerClientEvent('d4dz_inventory:client:Notify', src, "Citizen inventory wiped clean.", "success")
    else
        print("[d4dz] Citizen inventory wiped clean.")
    end
    TriggerClientEvent('d4dz_inventory:client:Notify', targetId, "Your entire inventory was cleared by administration.", "error")
end, false)
