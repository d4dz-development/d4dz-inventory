local itemDrops = {}
local activeStashes = {}

-- 1. Synchronize Ground Loot Drops with Connected Clients
local function RefreshGlobalDrops()
    TriggerClientEvent('d4dz_inventory:client:SyncDrops', -1, itemDrops)
end

-- 2. Handle Player Loading Initializations
RegisterNetEvent('d4dz_inventory:server:RequestPlayerInventory', function()
    local src = source
    local Player = D4DZCore.Functions.GetPlayer(src)
    
    if Player then
        -- Sync loaded player inventory data straight to player UI 
        TriggerClientEvent('d4dz_inventory:client:UpdateInventory', src, Player.PlayerData.items or {})
        TriggerClientEvent('d4dz_inventory:client:Notify', src, _U('inventory_loaded'), 'success')
    end
end)

-- 3. Processing Core Drag-and-Drop Relay Request Network Event
RegisterNetEvent('d4dz_inventory:server:ProcessItemMovement', function(data)
    local src = source
    -- Route secure parameters directly into functions.lua engine processing calculations
    HandleItemMovement(src, data)
end)

-- 4. Ground Loot Core Logic: Drop Item
RegisterNetEvent('d4dz_inventory:server:DropItem', function(itemName, qty, coords)
    local src = source
    local Player = D4DZCore.Functions.GetPlayer(src)
    if not Player then return end

    local itemConfig = Config.Items[itemName]
    if not itemConfig then return end

    -- Unique registration ID token for the specific ground drop entity instance
    local dropId = "drop_" .. os.time() .. "_" .. math.random(1111, 9999)

    itemDrops[dropId] = {
        name = itemName,
        label = itemConfig.label,
        qty = qty,
        coords = coords
    }

    RefreshGlobalDrops()
end)

-- 5. Ground Loot Core Logic: Pick Up Item
RegisterNetEvent('d4dz_inventory:server:PickupItemDrop', function(dropId)
    local src = source
    local Player = D4DZCore.Functions.GetPlayer(src)
    local dropData = itemDrops[dropId]

    if not Player or not dropData then return end

    -- High-performance authorization: Verify distance on the server side to block executors
    local playerPed = GetPlayerPed(src)
    local playerCoords = GetEntityCoords(playerPed)
    local distance = #(playerCoords - dropData.coords)

    if distance > 3.5 then
        TriggerClientEvent('d4dz_inventory:client:Notify', src, _U('too_far_drop'), 'error')
        return
    end

    -- Process standard inventory framework injection logic
    -- (Assuming Player.Functions.AddItem is provided natively by your d4dz-core framework module)
    if Player.Functions.AddItem(dropData.name, dropData.qty) then
        itemDrops[dropId] = nil -- Wipe out record array permanently
        RefreshGlobalDrops()
        TriggerClientEvent('d4dz_inventory:client:UpdateInventory', src, Player.PlayerData.items)
    else
        TriggerClientEvent('d4dz_inventory:client:Notify', src, _U('slots_full'), 'error')
    end
end)

-- 6. Secondary Containers (Trunk/Glovebox) Access Core Router
RegisterNetEvent('d4dz_inventory:server:OpenSecondaryStorage', function(storageData)
    local src = source
    -- Load structural array data records or populate default placeholder values if empty
    if not activeStashes[storageData.id] then
        activeStashes[storageData.id] = {}
    end

    -- Relays updated structural maps directly down to front-end NUI overlay slots configuration maps
    SendNUIMessage({
        action = "openSecondary",
        id = storageData.id,
        label = storageData.label,
        maxSlots = storageData.maxSlots,
        maxWeight = storageData.maxWeight,
        items = activeStashes[storageData.id]
    })
end)

RegisterNetEvent('d4dz_inventory:server:CloseInventory', function()
    local src = source
    SavePlayerInventory(src) -- Fire execution sequence tracking directly to MySQL tables via functions.lua
    TriggerClientEvent('d4dz_inventory:client:OnStorageClosed', src)
end)
