fx_version 'cerulean'
game 'gta5'

author 'd4dz'
description 'd4dz Premium Modular Inventory System'
version '1.0.0'

-- Shared configuration files loaded first
shared_scripts {
    'config/main.lua',
    'config/vehicles.lua',
    'locales/en.lua'
}

-- Client-side files
client_scripts {
    'client/main.lua',
    'client/drops.lua',
    'client/vehicles.lua'
}

-- Server-side files
server_scripts {
    'server/functions.lua',
    'server/main.lua',
    'server/commands.lua'
}

-- UI Asset declaration (NUI)
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/main.css',
    'html/app.js',
    'html/images/*.png'
}
