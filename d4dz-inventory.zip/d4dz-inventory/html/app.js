// 1. Core State Tracking Variables
let totalMaxSlots = 40;
let currentSecondaryInventoryId = null;

// 2. Global NUI Message Listener Thread
window.addEventListener('message', function(event) {
    const data = event.data;

    switch(data.action) {
        case "toggleInventory":
            const wrapper = document.getElementById('d4dz-inventory-wrapper');
            if (data.status) {
                totalMaxSlots = data.maxSlots || 40;
                wrapper.style.display = 'flex';
                // Automatically generate empty slots if they don't exist yet
                SetupEmptyGridSlots('player-slots-grid', totalMaxSlots, 'player');
            } else {
                wrapper.style.display = 'none';
                currentSecondaryInventoryId = null;
            }
            break;

        case "updateSlots":
            RenderInventoryItems('player-slots-grid', data.inventory, 'player');
            CalculateWeights('player', data.inventory, data.maxWeight);
            break;

        case "openSecondary":
            const secondaryPanel = document.getElementById('secondary-inventory-panel');
            const secondaryTitle = document.getElementById('secondary-title');
            
            currentSecondaryInventoryId = data.id;
            secondaryTitle.innerText = data.label || "Secondary Container";
            
            SetupEmptyGridSlots('secondary-slots-grid', data.maxSlots, data.id);
            RenderInventoryItems('secondary-slots-grid', data.items, data.id);
            CalculateWeights('secondary', data.items, data.maxWeight);
            break;
    }
});

// 3. Grid Slot Generator
function SetupEmptyGridSlots(gridId, slotCount, invType) {
    const grid = document.getElementById(gridId);
    grid.innerHTML = ''; // Wipe out previous layout structural tracks completely

    for (let i = 1; i <= slotCount; i++) {
        const slot = document.createElement('div');
        slot.classList.add('inventory-slot');
        slot.setAttribute('data-slot', i);
        slot.setAttribute('data-inventory', invType);

        // Append visual slot design indicator labels
        const slotNum = document.createElement('span');
        slotNum.classList.add('slot-number');
        slotNum.innerText = i;
        slot.appendChild(slotNum);

        // Register HTML5 drag-and-drop listener functions
        slot.addEventListener('dragover', OnDragOver);
        slot.addEventListener('drop', OnDropItem);

        grid.appendChild(slot);
    }
}

// 4. Render Active Inventory Items
function RenderInventoryItems(gridId, itemsData, invType) {
    // Clear out previously rendered items from this grid
    const targetSlots = document.querySelectorAll(`#${gridId} .inventory-slot`);
    targetSlots.forEach(slot => {
        const img = slot.querySelector('.item-image');
        const count = slot.querySelector('.item-count');
        if (img) img.remove();
        if (count) count.remove();
    });

    if (!itemsData) return;

    // Loop through item array pairs and inject asset elements
    Object.keys(itemsData).forEach(key => {
        const item = itemsData[key];
        if (!item) return;

        const slotElement = document.querySelector(`#${gridId} .inventory-slot[data-slot="${item.slot}"]`);
        if (!slotElement) return;

        // Construct structural image tags pointing to images folder
        const itemImg = document.createElement('img');
        itemImg.classList.add('item-image');
        itemImg.src = `images/${item.image || (item.name + '.png')}`;
        itemImg.setAttribute('draggable', 'true');

        // Store item attributes directly on the DOM entry for drag processing
        itemImg.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', JSON.stringify({
                fromSlot: item.slot,
                fromInventory: invType,
                itemName: item.name
            }));
        });

        const itemCount = document.createElement('span');
        itemCount.classList.add('item-count');
        itemCount.innerText = `x${item.amount}`;

        slotElement.appendChild(itemImg);
        slotElement.appendChild(itemCount);
    });
}

// 5. HTML5 Drag-and-Drop Interaction Mechanics
function OnDragOver(event) {
    event.preventDefault(); // Required authorization baseline to allow dropping items
}

function OnDropItem(event) {
    event.preventDefault();
    const targetSlotElement = event.currentTarget;
    const targetSlot = targetSlotElement.getAttribute('data-slot');
    const targetInventory = targetSlotElement.getAttribute('data-inventory');

    try {
        const dragData = JSON.parse(event.dataTransfer.getData('text/plain'));
        const moveAmount = parseInt(document.getElementById('item-amount-input').value) || 1;

        // Dispatch movement calculation arrays straight to client Lua runtime loops
        fetch(`https://${GetParentResourceName()}/moveItem`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                fromInventory: dragData.fromInventory,
                toInventory: targetInventory,
                fromSlot: dragData.fromSlot,
                toSlot: targetSlot,
                quantity: moveAmount,
                item: dragData.itemName
            })
        });
    } catch (err) {
        console.error("d4dz UI: Error decoding item transport layer metadata payload.");
    }
}

// 6. Dynamic Weight Tracker Fills Calculation
function CalculateWeights(type, items, maxWeight) {
    if (!maxWeight) maxWeight = 120000; // Grams breakdown fallbacks
    let totalWeight = 0;

    if (items) {
        Object.keys(items).forEach(key => {
            if (items[key]) {
                // Approximate calculation (Real logic calculated safely on server functions.lua)
                totalWeight += (items[key].weight || 500) * items[key].amount;
            }
        });
    }

    const currentKg = (totalWeight / 1000).toFixed(1);
    const maxKg = (maxWeight / 1000).toFixed(1);
    const fillPercent = Math.min((totalWeight / maxWeight) * 100, 100);

    document.getElementById(`${type}-weight-text`).innerText = `${currentKg} / ${maxKg} kg`;
    document.getElementById(`${type}-weight-fill`).style.width = `${fillPercent}%`;
}

// 7. Interactive Closer Action Click Handler Button Event
document.getElementById('close-inventory-btn').addEventListener('click', function() {
    fetch(`https://${GetParentResourceName()}/closeInventoryUI`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
});

// ESC Key Close Listener
window.addEventListener('keydown', function(event) {
    if (event.key === "Escape") {
        document.getElementById('close-inventory-btn').click();
    }
});
