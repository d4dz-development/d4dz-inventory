Locales = Locales or {}

Locales['en'] = {
    -- Core System Notifications
    ['system_title'] = "d4dz Inventory System",
    ['inventory_loaded'] = "Your personal storage inventory has been synced.",
    ['weight_limit'] = "You cannot carry this item, it exceeds your weight capacity!",
    ['slots_full'] = "No available inventory slot slots remaining!",
    ['invalid_action'] = "Action denied by d4dz core system safety protocols.",

    -- Give / Trade Interactions
    ['item_given'] = "You successfully gave x%s %s to ID %s.",
    ['item_received'] = "You received x%s %s from ID %s.",
    ['no_player_near'] = "No citizens detected within your immediate vicinity.",

    -- Vehicle Storage Interaction
    ['trunk_open'] = "Opening vehicle trunk storage unit...",
    ['trunk_closed'] = "Closing vehicle trunk storage unit...",
    ['glovebox_open'] = "Opening vehicle glove compartment...",
    ['glovebox_locked'] = "This vehicle compartment is currently secured and locked.",

    -- Ground Loot Drops
    ['drop_item_label'] = "[E] Pick up %s (x%s)",
    ['too_far_drop'] = "You are standing too far away to secure this dropped item.",
    
    -- UI Visual Elements
    ['ui_player_inv'] = "Personal Inventory",
    ['ui_secondary_inv'] = "Secondary Container",
    ['ui_weight_display'] = "Weight: %s / %s kg",
    ['ui_search_placeholder'] = "Filter assets..."
}

-- Helper function to access localization phrases dynamically across scripts
function _U(phrase, ...)
    if Locales['en'] and Locales['en'][phrase] then
        return string.format(Locales['en'][phrase], ...)
    end
    return "Translation Missing: " .. phrase
end
