local currentVehicle = nil
local currentPlate = nil
local currentStorageType = nil

-- 1. Helper Function to Get Closest Vehicle
local function GetClosestVehicleData()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    -- Built-in FiveM native to fetch the closest vehicle handle
    local vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 4.0, 0, 71)
    
    if vehicle and DoesEntityExist(vehicle) then
        return vehicle, GetVehicleNumberPlateText(vehicle), GetVehicleClass(vehicle)
    end
    return nil, nil, nil
end

-- 2. Commands to Open Storage Targets
RegisterCommand('open_trunk', function()
    local vehicle, plate, class = GetClosestVehicleData()
    if not vehicle then 
        TriggerEvent('d4dz_inventory:client:Notify', _U('no_player_near'), 'error')
        return 
    end

    -- Prevent looking inside moving vehicles
    if GetEntitySpeed(vehicle) > 1.0 then return end

    -- Verify vehicle locking mechanism status (unlocked = 1 or 0)
    local lockStatus = GetVehicleDoorLockStatus(vehicle)
    if lockStatus > 1 then
        TriggerEvent('d4dz_inventory:client:Notify', _U('glovebox_locked'), 'error')
        return
    end

    currentVehicle = vehicle
    currentPlate = plate
    currentStorageType = "trunk"

    -- Visually pop open the physical trunk door
    SetVehicleDoorOpen(vehicle, 5, false, false)
    TriggerEvent('d4dz_inventory:client:Notify', _U('trunk_open'), 'success')

    -- Fetch capacity limits from config/vehicles.lua
    local classConfig = Config.VehicleStorage.Classes[class] or Config.VehicleStorage.Classes[1] -- Fallback to Sedan

    TriggerServerEvent('d4dz_inventory:server:OpenSecondaryStorage', {
        id = "trunk_" .. plate,
        type = "trunk",
        maxWeight = classConfig.trunkWeight,
        maxSlots = classConfig.trunkSlots,
        label = classConfig.label .. " Trunk"
    })
end, false)

RegisterCommand('open_glovebox', function()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    
    -- Player must be sitting inside the vehicle to access the glove box
    if vehicle == 0 then return end
    
    local plate = GetVehicleNumberPlateText(vehicle)
    local class = GetVehicleClass(vehicle)
    local classConfig = Config.VehicleStorage.Classes[class] or Config.VehicleStorage.Classes[1]

    -- Handle bike exceptions (like motorcycles having 0 slots in config)
    if classConfig.gloveSlots <= 0 then return end

    currentVehicle = vehicle
    currentPlate = plate
    currentStorageType = "glovebox"

    TriggerEvent('d4dz_inventory:client:Notify', _U('glovebox_open'), 'success')

    TriggerServerEvent('d4dz_inventory:server:OpenSecondaryStorage', {
        id = "glove_" .. plate,
        type = "glovebox",
        maxWeight = classConfig.gloveWeight,
        maxSlots = classConfig.gloveSlots,
        label = "Glove Compartment"
    })
end, false)

-- 3. Closing Sequence Trigger
RegisterNetEvent('d4dz_inventory:client:OnStorageClosed', function()
    if currentStorageType == "trunk" and currentVehicle and DoesEntityExist(currentVehicle) then
        SetVehicleDoorShut(currentVehicle, 5, false)
        TriggerEvent('d4dz_inventory:client:Notify', _U('trunk_closed'), 'primary')
    end
    currentVehicle = nil
    currentPlate = nil
    currentStorageType = nil
end)
