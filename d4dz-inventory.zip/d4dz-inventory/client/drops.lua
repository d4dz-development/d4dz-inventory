local nearbyDrops = {}
local activeDropId = nil

-- 1. Receive Drop Syncs from Server
RegisterNetEvent('d4dz_inventory:client:SyncDrops', function(serverDrops)
    nearbyDrops = serverDrops
end)

-- 2. Main High-Performance Interaction Thread
Citizen.CreateThread(function()
    while true do
        local sleep = 1000 -- Sleep thread when no drops are nearby
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        activeDropId = nil

        for dropId, dropData in pairs(nearbyDrops) do
            local distance = #(playerCoords - dropData.coords)

            -- Render 3D environment marker if close enough (within 15 meters)
            if distance < 15.0 then
                sleep = 0
                DrawMarker(2, dropData.coords.x, dropData.coords.y, dropData.coords.z - 0.2, 
                    0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 0.2, 0.2, 0.2, 
                    210, 180, 40, 150, false, true, 2, false, nil, nil, false
                )

                -- Register proximity targeting if within 1.5 meters
                if distance < 1.5 then
                    activeDropId = dropId
                    
                    -- Display floating text notification using locales
                    local displayMsg = _U('drop_item_label', dropData.label, dropData.qty)
                    BeginTextCommandDisplayHelp("STRING")
                    AddTextComponentSubstringPlayerName(displayMsg)
                    EndTextCommandDisplayHelp(0, false, true, -1)
                end
            end
        end
        
        Citizen.Wait(sleep)
    end
end)

-- 3. Input Key Listener for [E] Pick Up Key
Citizen.CreateThread(function()
    while true do
        local sleep = 250
        if activeDropId then
            sleep = 0
            -- Check for INPUT_CONTEXT (Default 'E' key on keyboard)
            if IsControlJustPressed(0, 38) then 
                local currentDrop = activeDropId -- Lock variable to avoid async conflicts
                TriggerServerEvent('d4dz_inventory:server:PickupItemDrop', currentDrop)
                Citizen.Wait(500) -- Simple debounce protection
            end
        end
        Citizen.Wait(sleep)
    end
end)
