D4DZCore = nil
local isInventoryOpen = false
local playerInventory = {}

-- 1. Initialize Framework Integration
Citizen.CreateThread(function()
    while D4DZCore == nil do
        -- Triggers export connection to your custom d4dz-core
        TriggerEvent('d4dz-core:GetCoreObject', function(obj) D4DZCore = obj end)
        Citizen.Wait(200)
    end
    
    -- Sync inventory data immediately upon successful loading
    TriggerServerEvent('d4dz_inventory:server:RequestPlayerInventory')
end)

-- 2. Open / Close Inventory Logic
local function ToggleInventory(status)
    if status == isInventoryOpen then return end
    isInventoryOpen = status
    
    -- Unlock or lock mouse cursor focus for game window
    SetNuiFocus(isInventoryOpen, isInventoryOpen)
    
    -- Send visibility switch state straight to front-end HTML
    SendNUIMessage({
        action = "toggleInventory",
        status = isInventoryOpen,
        maxSlots = Config.MaxSlots,
        maxWeight = Config.MaxWeight
    })
    
    if not isInventoryOpen then
        TriggerServerEvent('d4dz_inventory:server:CloseInventory')
    end
end

-- 3. Core Keybind & Command Registration
RegisterCommand('toggleinventory', function()
    -- Prevent opening inventory if player is down or cuffed (Integrate with core states)
    local isDead = LocalPlayer.state.isDead or false
    if isDead then return end
    
    ToggleInventory(not isInventoryOpen)
end, false)

-- Maps the command to the user-defined keyboard config setting
RegisterKeyMapping('toggleinventory', 'Open d4dz Inventory', 'keyboard', Config.ToggleKey)

-- 4. Front-End NUI Callbacks
RegisterNUICallback('closeInventoryUI', function(data, cb)
    ToggleInventory(false)
    cb('ok')
end)

RegisterNUICallback('moveItem', function(data, cb)
    -- Relays front-end drag-and-drop actions securely to server validation
    TriggerServerEvent('d4dz_inventory:server:ProcessItemMovement', data)
    cb('ok')
end)

-- 5. Data Synchronization Events
RegisterNetEvent('d4dz_inventory:client:UpdateInventory', function(updatedInventory)
    playerInventory = updatedInventory
    SendNUIMessage({
        action = "updateSlots",
        inventory = playerInventory
    })
end)
