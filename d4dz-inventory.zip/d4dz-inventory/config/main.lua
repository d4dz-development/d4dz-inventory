Config = {}

-- Framework Settings (Set to your custom core architecture)
Config.Framework = 'd4dz-core' 

-- Inventory Settings
Config.MaxSlots = 40            -- Total player inventory item slots
Config.MaxWeight = 120000       -- Total weight limit in grams (120kg)
Config.ToggleKey = 'I'          -- Default button to open the interface

-- Custom d4dz Core Items List
Config.Items = {
    ["water"] = {
        name = "water",
        label = "Bottled Water",
        weight = 500,           -- Weight in grams
        type = "item",
        unique = false,
        usable = true,
        image = "water.png"
    },
    ["bread"] = {
        name = "bread",
        label = "Fresh Bread",
        weight = 250,
        type = "item",
        unique = false,
        usable = true,
        image = "bread.png"
    },
    ["phone"] = {
        name = "phone",
        label = "Mobile Phone",
        weight = 150,
        type = "item",
        unique = true,          -- Has metadata (phone number)
        usable = true,
        image = "phone.png"
    }
}
