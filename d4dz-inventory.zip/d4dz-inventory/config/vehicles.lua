Config = Config or {}

Config.VehicleStorage = {
    -- Default configurations for vehicle categories (0-21 GTA Vehicle Classes)
    Classes = {
        [0]  = { label = "Compact", trunkWeight = 30000, trunkSlots = 15, gloveWeight = 5000, gloveSlots = 5 },
        [1]  = { label = "Sedan", trunkWeight = 50000, trunkSlots = 20, gloveWeight = 5000, gloveSlots = 5 },
        [2]  = { label = "SUV", trunkWeight = 80000, trunkSlots = 30, gloveWeight = 8000, gloveSlots = 8 },
        [3]  = { label = "Coupe", trunkWeight = 40000, trunkSlots = 15, gloveWeight = 5000, gloveSlots = 5 },
        [4]  = { label = "Muscle", trunkWeight = 45000, trunkSlots = 15, gloveWeight = 5000, gloveSlots = 5 },
        [5]  = { label = "Sports", trunkWeight = 25000, trunkSlots = 10, gloveWeight = 3000, gloveSlots = 4 },
        [6]  = { label = "Super", trunkWeight = 15000, trunkSlots = 5, gloveWeight = 2000, gloveSlots = 3 },
        [7]  = { label = "Off-Road", trunkWeight = 90000, trunkSlots = 35, gloveWeight = 8000, gloveSlots = 8 },
        [8]  = { label = "Motorcycle", trunkWeight = 5000, trunkSlots = 5, gloveWeight = 0, gloveSlots = 0 },
        [12] = { label = "Van", trunkWeight = 150000, trunkSlots = 50, gloveWeight = 10000, gloveSlots = 10 }
    },

    -- Custom overrides for specific model names
    Overrides = {
        ["burrito"] = { trunkWeight = 200000, trunkSlots = 60, gloveWeight = 10000, gloveSlots = 10 }
    }
}
